package info.razibkani.nightmodesample;

/**
 * Created by razibkani on 3/18/17.
 */

public class News {

    public String title;
    public String description;
    public String date;

}