# Android-Night-Mode
simple implementation night mode android

![Screenshot](https://github.com/RazibKani/Android-Night-Mode/blob/master/night_mode.png)
